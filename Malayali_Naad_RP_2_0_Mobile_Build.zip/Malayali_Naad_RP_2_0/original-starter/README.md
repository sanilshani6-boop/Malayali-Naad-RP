# മലയാളി നാട് Roleplay — SA-MP 0.3.7 Starter

A starter Pawn roleplay gamemode for a Malayalam/Kerala-themed SA-MP server.

## Included
- MySQL account table and account registration/login
- Salted SHA-256 password hashes (SA-MP `SHA256_PassHash`)
- Persistent money, admin level, faction, job and level
- Starter jobs: Fisherman, Delivery Driver, Farmer
- Basic faction IDs: Police, Medical, Government, News
- Basic admin/faction assignment commands
- Starter economy and player-to-player payment
- `server.cfg` and SQL schema

## Requirements
Use a compatible SA-MP 0.3.7 server package and the following server-side dependencies:
1. BlueG MySQL plugin and its matching `a_mysql.inc`
2. sscanf plugin and matching `sscanf2.inc`
3. A Pawn compiler compatible with your server package

Place the plugin binaries in `plugins/`, includes in `pawno/include/`, and compile
`gamemodes/MNRP.pwn` to `gamemodes/MNRP.amx`.

## Database setup
1. Install MySQL/MariaDB.
2. Import `scriptfiles/malayali_naad_rp.sql` using phpMyAdmin or:
   `mysql -u root -p < scriptfiles/malayali_naad_rp.sql`
3. Create a dedicated database user and grant it access to `malayali_naad_rp`.
4. Edit `MYSQL_HOST`, `MYSQL_USER`, `MYSQL_PASS`, and `MYSQL_DATABASE` near the top
   of `gamemodes/MNRP.pwn`.
5. Recompile the gamemode.

## Server setup
1. Copy the SA-MP server distribution files into this project folder.
2. Add the MySQL and sscanf plugin binaries to `plugins/`.
3. Confirm `plugins mysql sscanf` in `server.cfg` matches the plugin filenames.
4. Change `rcon_password` in `server.cfg`.
5. Start `samp-server.exe` on Windows or `./samp03svr` on Linux.
6. Connect to `YOUR_SERVER_IP:7777`.

## Commands
- `/help` — command help
- `/stats` — account stats
- `/job` — select one of three starter jobs
- `/work` — earn a starter payment
- `/faction` — show faction ID
- `/pay` — transfer money to another online player
- `/makeadmin` — RCON administrator can set an admin level
- `/setfaction` — admin level 3+ can set a faction

Faction IDs:
- 0: No faction
- 1: Kerala Police Department
- 2: Kerala Medical Services
- 3: Government
- 4: News

## Important starter limitations
This is a foundation, not a production-ready public server. The `/work` command
currently pays immediately and should be upgraded with job locations, cooldowns,
animations and anti-abuse checks. Add server-side validation, logs, rate limits,
backup/restore, stronger password hashing, and proper admin audit logs before
opening the server to the public.

The gamemode uses `sscanf` in dialog parsing, so the sscanf include and plugin are
required. Keep the MySQL plugin version and include file matched. Do not expose
your database password or RCON password.
