CREATE DATABASE IF NOT EXISTS `malayali_naad_rp`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `malayali_naad_rp`;

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(24) NOT NULL,
  `password_hash` CHAR(64) NOT NULL,
  `salt` VARCHAR(16) NOT NULL,
  `money` INT NOT NULL DEFAULT 5000,
  `admin` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `faction` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `job` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `level` INT UNSIGNED NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `factions` (
  `id` TINYINT UNSIGNED NOT NULL,
  `name` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `factions` (`id`,`name`) VALUES
(1,'Kerala Police Department'),
(2,'Kerala Medical Services'),
(3,'Government of Malayali Naad'),
(4,'Malayali Naad News');

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` TINYINT UNSIGNED NOT NULL,
  `name` VARCHAR(64) NOT NULL,
  `base_pay` INT UNSIGNED NOT NULL DEFAULT 250,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `jobs` (`id`,`name`,`base_pay`) VALUES
(1,'Fisherman',300),(2,'Delivery Driver',350),(3,'Farmer',275);
