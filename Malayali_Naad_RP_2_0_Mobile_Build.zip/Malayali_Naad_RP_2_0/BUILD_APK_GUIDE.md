# Build the Android APK

The launcher source is a native Kotlin Android Studio project.

## Build on Windows, macOS or Linux
1. Install Android Studio and JDK 17.
2. Install Android SDK Platform 35 and Android Build Tools using SDK Manager.
3. Open the `android-launcher` folder in Android Studio.
4. Wait for Gradle sync to finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio creates the debug APK at:
   `android-launcher/app/build/outputs/apk/debug/app-debug.apk`

For a distributable release, configure a signing key and use **Build > Generate Signed Bundle / APK**.

## Before publishing
- Replace the placeholder server IP with your actual public server address.
- Add the official community/Discord URL and privacy policy.
- Test the `samp://` handoff with the exact Android client your players use.
- This launcher does not include GTA San Andreas or a multiplayer client.

## Why this bundle does not contain an APK
The build environment used to prepare this source bundle does not have the Android SDK / Android Gradle build toolchain installed. The source project is ready to open and build in Android Studio, but no APK binary is claimed or included.
