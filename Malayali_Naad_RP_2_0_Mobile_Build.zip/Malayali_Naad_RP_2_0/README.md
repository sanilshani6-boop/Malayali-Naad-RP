# Malayali Naad RP 2.0 Bundle

This bundle contains:
- `server/`: expanded SA-MP 0.3.7 Pawn/MySQL starter gamemode and SQL schema.
- `android-launcher/`: native Kotlin Android Studio launcher project.

Important: the supplied launcher is companion software, not the GTA game/client. The server source needs the matching BlueG MySQL and sscanf plugin/include versions and must be compiled with a compatible Pawn compiler. The Kerala-themed locations are labels on the existing San Andreas map; a true custom Kerala map needs additional map objects and a streaming setup.

See each folder's README for setup instructions.
