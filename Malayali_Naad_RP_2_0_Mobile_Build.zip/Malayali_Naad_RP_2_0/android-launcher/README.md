# Malayali Naad RP Android Launcher

Native Android companion launcher (Kotlin, no third-party UI dependencies), green/black Kerala theme.

## Features
- Server host + port entry
- Copy `host:port`
- Open `samp://host:port` with an installed compatible client, if one is registered
- Community information, faction overview, rules and connection help

## Build APK
1. Open this `android-launcher` folder in Android Studio (Hedgehog or newer recommended).
2. Allow Gradle sync and install Android SDK Platform 35 + JDK 17.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

This source project is not itself a compiled APK. Building requires Android Studio/Android SDK. It does not bundle GTA San Andreas or a multiplayer game client. The `samp://` handoff only works if a compatible client is installed and handles that URI scheme.

Before publishing, add your real server host, official Discord URL, privacy policy, app icon, and a tested client URI scheme. Test on your target Android devices.
