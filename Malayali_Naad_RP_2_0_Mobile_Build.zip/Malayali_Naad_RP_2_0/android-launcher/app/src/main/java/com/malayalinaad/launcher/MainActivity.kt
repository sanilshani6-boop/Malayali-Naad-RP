package com.malayalinaad.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 18, 12)
    private val panel = Color.rgb(16, 35, 24)
    private val green = Color.rgb(65, 214, 111)
    private val white = Color.WHITE
    private lateinit var ipInput: EditText
    private lateinit var portInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(22))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val emblem = TextView(this).apply {
            text = "കേരളം"
            textSize = 17f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        content.addView(emblem, matchWrap())

        val title = TextView(this).apply {
            text = "മലയാളി നാട്"
            textSize = 34f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        content.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "ROLEPLAY  •  YOUR LIFE, YOUR STORY"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(22))
        }
        content.addView(subtitle, matchWrap())

        val serverCard = card()
        serverCard.addView(label("SERVER CONNECTION"))
        ipInput = EditText(this).apply {
            hint = "Server IP address"
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), 0, dp(14), 0)
            setBackgroundColor(Color.rgb(27, 49, 35))
        }
        serverCard.addView(ipInput, fieldParams())
        portInput = EditText(this).apply {
            hint = "Port (default 7777)"
            setSingleLine(true)
            inputType = 2
            setText("7777")
            setTextColor(white)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), 0, dp(14), 0)
            setBackgroundColor(Color.rgb(27, 49, 35))
        }
        serverCard.addView(portInput, fieldParams())
        serverCard.addView(actionButton("COPY SERVER ADDRESS") { copyAddress() })
        serverCard.addView(actionButton("OPEN SA-MP CLIENT") { openClient() })
        content.addView(serverCard, matchWrap())

        val infoCard = card()
        infoCard.addView(label("MALAYALI NAAD COMMUNITY"))
        infoCard.addView(infoText("🇮🇳  Kerala-inspired Malayalam roleplay"))
        infoCard.addView(infoText("👮  Police • Medical • Government • News"))
        infoCard.addView(infoText("💼  Jobs • Banking • Businesses • Properties"))
        infoCard.addView(infoText("🎮  SA-MP 0.3.7 • Up to 200 players"))
        infoCard.addView(actionButton("SERVER RULES") {
            showInfo("Server Rules", "Respect all players. No cheats, hacks, exploits or abuse. Follow roleplay rules and staff instructions. Do not share passwords.")
        })
        infoCard.addView(actionButton("ABOUT / CONNECTION HELP") {
            showInfo("Connection Help", "Enter your SA-MP server IP and port, then copy the address. OPEN SA-MP CLIENT sends a samp:// link to a compatible client if one is installed. This launcher does not contain the GTA game or SA-MP client.")
        })
        content.addView(infoCard, matchWrap())

        val footer = TextView(this).apply {
            text = "മലയാളി നാട് RP  |  COMMUNITY LAUNCHER"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(8))
        }
        content.addView(footer, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun copyAddress() {
        val address = addressOrNull() ?: return
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("MNRP server", address))
        Toast.makeText(this, "Copied: $address", Toast.LENGTH_SHORT).show()
    }

    private fun openClient() {
        val address = addressOrNull() ?: return
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("samp://$address"))
        try {
            startActivity(intent)
        } catch (_: Exception) {
            showInfo("SA-MP client not found", "No app on this device accepted the samp:// link. Install a compatible SA-MP Android client separately, or copy the server address and connect using your client.")
        }
    }

    private fun addressOrNull(): String? {
        val ip = ipInput.text.toString().trim()
        val port = portInput.text.toString().trim().ifEmpty { "7777" }
        if (ip.isBlank() || ip.contains(" ") || port.toIntOrNull() !in 1..65535) {
            Toast.makeText(this, "Enter a valid IP/host and port.", Toast.LENGTH_LONG).show()
            return null
        }
        return "$ip:$port"
    }

    private fun showInfo(title: String, message: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle(title).setMessage(message)
            .setPositiveButton("OK", null).show()
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(16)
        layoutParams = lp
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        letterSpacing = 0.1f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(green)
        setPadding(0, 0, 0, dp(12))
    }

    private fun infoText(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(white)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun actionButton(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.rgb(5, 22, 12))
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, dp(48))
        lp.topMargin = dp(10)
        layoutParams = lp
    }

    private fun fieldParams() = LinearLayout.LayoutParams(-1, dp(50)).apply {
        bottomMargin = dp(10)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
