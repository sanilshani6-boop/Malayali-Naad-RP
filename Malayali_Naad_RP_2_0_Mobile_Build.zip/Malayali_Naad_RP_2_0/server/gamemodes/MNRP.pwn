#include <a_samp>
#include <a_mysql>
#include <sscanf2>

#define MYSQL_HOST      "127.0.0.1"
#define MYSQL_USER      "root"
#define MYSQL_PASS      "CHANGE_ME"
#define MYSQL_DATABASE  "malayali_naad_rp"

#define DIALOG_LOGIN    1000
#define DIALOG_REGISTER 1001
#define COLOR_GREEN     0x33CC66FF
#define COLOR_RED       0xE74C3CFF
#define COLOR_WHITE     0xFFFFFFFF
#define COLOR_YELLOW    0xF1C40FFF

new MySQL:g_SQL;
new bool:g_Logged[MAX_PLAYERS];
new g_Money[MAX_PLAYERS];
new g_Bank[MAX_PLAYERS];
new g_FactionRank[MAX_PLAYERS];
new g_LastWork[MAX_PLAYERS];
new g_Admin[MAX_PLAYERS];
new g_Faction[MAX_PLAYERS];
new g_Job[MAX_PLAYERS];
new g_Level[MAX_PLAYERS];
new g_AccountID[MAX_PLAYERS];
new g_LoginAttempts[MAX_PLAYERS];
new g_Salt[MAX_PLAYERS][17];
new g_PasswordHash[MAX_PLAYERS][65];
new g_PlayerName[MAX_PLAYERS][MAX_PLAYER_NAME + 1];

forward OnAccountCheck(playerid);
forward OnAccountRegistered(playerid);
forward OnAccountLoaded(playerid);

main() {}

public OnGameModeInit()
{
    SetGameModeText("Malayali Naad Roleplay");
    ShowPlayerMarkers(PLAYER_MARKERS_MODE_GLOBAL);
    ShowNameTags(true);
    SetNameTagDrawDistance(35.0);
    EnableStuntBonusForAll(false);
    DisableInteriorEnterExits();

    AddPlayerClass(0, 1685.5, -2240.0, 13.5, 90.0, 0, 0, 0, 0, 0, 0);
    AddPlayerClass(60, 1685.5, -2240.0, 13.5, 90.0, 0, 0, 0, 0, 0, 0);

    // Kerala-themed RP hubs placed on the existing San Andreas map.
    Create3DTextLabel("തിരുവനന്തപുരം സെക്രട്ടേറിയറ്റ് | Government", 0x33CC66FF, 1481.0, -1771.0, 18.8, 35.0, 0, 1);
    Create3DTextLabel("കേരള പോലീസ് ഹെഡ്ക്വാർട്ടേഴ്സ്", 0x33CC66FF, 1554.0, -1675.0, 16.2, 35.0, 0, 1);
    Create3DTextLabel("കേരള മെഡിക്കൽ സർവീസ്", 0x33CC66FF, 1172.0, -1323.0, 15.4, 35.0, 0, 1);
    Create3DTextLabel("മലയാളി നാട് വാർത്താ കേന്ദ്രം", 0x33CC66FF, 736.0, -1335.0, 13.5, 35.0, 0, 1);
    Create3DTextLabel("ബാങ്ക് ഓഫ് മലയാളി നാട്", 0x33CC66FF, 1464.0, -1025.0, 24.0, 35.0, 0, 1);

    g_SQL = mysql_connect(MYSQL_HOST, MYSQL_USER, MYSQL_PASS, MYSQL_DATABASE);
    if (mysql_errno(g_SQL) != 0)
    {
        print("[MNRP] MySQL connection failed. Check credentials and server.");
    }
    else
    {
        print("[MNRP] MySQL connected successfully.");
    }
    return 1;
}

public OnGameModeExit()
{
    mysql_close(g_SQL);
    return 1;
}

public OnPlayerConnect(playerid)
{
    GetPlayerName(playerid, g_PlayerName[playerid], MAX_PLAYER_NAME);
    g_Logged[playerid] = false;
    g_Money[playerid] = 5000;
    g_Bank[playerid] = 0;
    g_FactionRank[playerid] = 0;
    g_LastWork[playerid] = 0;
    g_Admin[playerid] = 0;
    g_Faction[playerid] = 0;
    g_Job[playerid] = 0;
    g_Level[playerid] = 1;
    g_AccountID[playerid] = 0;
    g_LoginAttempts[playerid] = 0;

    new query[256];
    mysql_format(g_SQL, query, sizeof query,
        "SELECT `id` FROM `accounts` WHERE `username`='%e' LIMIT 1",
        g_PlayerName[playerid]);
    mysql_tquery(g_SQL, query, "OnAccountCheck", "i", playerid);
    SendClientMessage(playerid, COLOR_GREEN, "സ്വാഗതം! Malayali Naad Roleplay-ലേക്ക് സ്വാഗതം.");
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    if (g_Logged[playerid])
    {
        SaveAccount(playerid);
    }
    g_Logged[playerid] = false;
    return 1;
}

public OnPlayerRequestClass(playerid, classid)
{
    if (!g_Logged[playerid])
    {
        SetPlayerCameraPos(playerid, 1688.0, -2235.0, 18.0);
        SetPlayerCameraLookAt(playerid, 1685.5, -2240.0, 13.5);
    }
    return 1;
}

public OnPlayerSpawn(playerid)
{
    if (!g_Logged[playerid])
    {
        TogglePlayerSpectating(playerid, true);
        return 1;
    }
    SetPlayerSkin(playerid, 0);
    SetPlayerPos(playerid, 1685.5, -2240.0, 13.5);
    SetPlayerFacingAngle(playerid, 90.0);
    SetCameraBehindPlayer(playerid);
    ResetPlayerMoney(playerid);
    GivePlayerMoney(playerid, g_Money[playerid]);
    return 1;
}

public OnAccountCheck(playerid)
{
    if (!IsPlayerConnected(playerid)) return 1;

    if (cache_num_rows() > 0)
    {
        ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD,
            "Malayali Naad RP - Login",
            "നിങ്ങളുടെ അക്കൗണ്ട് പാസ്‌വേഡ് നൽകുക:", "Login", "Quit");
    }
    else
    {
        ShowPlayerDialog(playerid, DIALOG_REGISTER, DIALOG_STYLE_PASSWORD,
            "Malayali Naad RP - Register",
            "പുതിയ അക്കൗണ്ട് സൃഷ്ടിക്കാൻ പാസ്‌വേഡ് നൽകുക:", "Register", "Quit");
    }
    return 1;
}

public OnAccountRegistered(playerid)
{
    if (!IsPlayerConnected(playerid)) return 1;
    if (cache_affected_rows() > 0)
    {
        SendClientMessage(playerid, COLOR_GREEN, "അക്കൗണ്ട് സൃഷ്ടിച്ചു! വീണ്ടും കണക്റ്റ് ചെയ്ത് ലോഗിൻ ചെയ്യുക.");
        Kick(playerid);
    }
    else
    {
        SendClientMessage(playerid, COLOR_RED, "Registration failed. Please contact an administrator.");
        Kick(playerid);
    }
    return 1;
}

public OnAccountLoaded(playerid)
{
    if (!IsPlayerConnected(playerid)) return 1;
    if (cache_num_rows() == 0)
    {
        SendClientMessage(playerid, COLOR_RED, "അക്കൗണ്ട് കണ്ടെത്താനായില്ല.");
        Kick(playerid);
        return 1;
    }

    cache_get_value_name_int(0, "id", g_AccountID[playerid]);
    cache_get_value_name_int(0, "money", g_Money[playerid]);
    cache_get_value_name_int(0, "bank", g_Bank[playerid]);
    cache_get_value_name_int(0, "faction_rank", g_FactionRank[playerid]);
    cache_get_value_name_int(0, "admin", g_Admin[playerid]);
    cache_get_value_name_int(0, "faction", g_Faction[playerid]);
    cache_get_value_name_int(0, "job", g_Job[playerid]);
    cache_get_value_name_int(0, "level", g_Level[playerid]);

    g_Logged[playerid] = true;
    TogglePlayerSpectating(playerid, false);
    SpawnPlayer(playerid);
    SendClientMessage(playerid, COLOR_GREEN, "ലോഗിൻ വിജയിച്ചു! /help ഉപയോഗിച്ച് commands കാണുക.");
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if (!response) return 1;

    if (dialogid == DIALOG_REGISTER)
    {
        if (strlen(inputtext) < 6 || strlen(inputtext) > 32)
        {
            ShowPlayerDialog(playerid, DIALOG_REGISTER, DIALOG_STYLE_PASSWORD,
                "Register", "Password must be 6-32 characters. വീണ്ടും ശ്രമിക്കുക:", "Register", "Quit");
            return 1;
        }
        format(g_Salt[playerid], 17, "%06d%06d", random(999999), random(999999));
        SHA256_PassHash(inputtext, g_Salt[playerid], g_PasswordHash[playerid], 65);
        new query[512];
        mysql_format(g_SQL, query, sizeof query,
            "INSERT INTO `accounts` (`username`,`password_hash`,`salt`,`money`,`level`) VALUES ('%e','%e','%e',5000,1)",
            g_PlayerName[playerid], g_PasswordHash[playerid], g_Salt[playerid]);
        mysql_tquery(g_SQL, query, "OnAccountRegistered", "i", playerid);
        return 1;
    }
    if (dialogid == DIALOG_LOGIN)
    {
        new query[256];
        mysql_format(g_SQL, query, sizeof query,
            "SELECT * FROM `accounts` WHERE `username`='%e' LIMIT 1", g_PlayerName[playerid]);
        mysql_tquery(g_SQL, query, "OnLoginPasswordCheck", "is", playerid, inputtext);
        return 1;
    }
    if (dialogid == 1002)
    {
        g_Job[playerid] = listitem + 1;
        SendClientMessage(playerid, COLOR_GREEN, "ജോലി തിരഞ്ഞെടുക്കപ്പെട്ടു! ജോലി വരുമാനത്തിന് /work ഉപയോഗിക്കുക.");
        SaveAccount(playerid);
        return 1;
    }
    if (dialogid == 1003 && IsPlayerAdmin(playerid))
    {
        new target, level;
        if (sscanf(inputtext, "p<,>ii", target, level))
        {
            SendClientMessage(playerid, COLOR_RED, "Format: PlayerID,Level. sscanf plugin/include വേണം; അല്ലെങ്കിൽ config-ൽ RCON setup പരിശോധിക്കുക.");
            return 1;
        }
        if (!IsPlayerConnected(target) || level < 0 || level > 5) return 1;
        g_Admin[target] = level;
        SaveAccount(target);
        SendClientMessage(target, COLOR_GREEN, "നിങ്ങളുടെ admin level മാറ്റിയിട്ടുണ്ട്.");
        return 1;
    }
    if (dialogid == 1004 && g_Admin[playerid] >= 3)
    {
        new target, faction;
        if (sscanf(inputtext, "p<,>ii", target, faction)) return SendClientMessage(playerid, COLOR_RED, "Format: PlayerID,FactionID"), 1;
        if (!IsPlayerConnected(target) || faction < 0 || faction > 6) return 1;
        g_Faction[target] = faction;
        g_FactionRank[target] = (faction == 0) ? 0 : 1;
        SaveAccount(target);
        new factionLog[256];
        mysql_format(g_SQL, factionLog, sizeof factionLog,
            "INSERT INTO `admin_logs` (`admin_name`,`target_name`,`action`,`details`) VALUES ('%e','%e','SETFACTION','faction=%d')",
            g_PlayerName[playerid], g_PlayerName[target], faction);
        mysql_tquery(g_SQL, factionLog);
        SendClientMessage(target, COLOR_GREEN, "നിങ്ങളുടെ faction മാറ്റിയിട്ടുണ്ട്.");
        return 1;
    }
    if (dialogid == 1005)
    {
        new target, amount;
        if (sscanf(inputtext, "p<,>ii", target, amount)) return SendClientMessage(playerid, COLOR_RED, "Format: PlayerID,Amount"), 1;
        if (!IsPlayerConnected(target) || target == playerid || amount < 1 || amount > g_Money[playerid]) return 1;
        g_Money[playerid] -= amount;
        g_Money[target] += amount;
        ResetPlayerMoney(playerid); GivePlayerMoney(playerid, g_Money[playerid]);
        ResetPlayerMoney(target); GivePlayerMoney(target, g_Money[target]);
        SaveAccount(playerid); SaveAccount(target);
        SendClientMessage(playerid, COLOR_GREEN, "പണം അയച്ചു.");
        SendClientMessage(target, COLOR_GREEN, "നിങ്ങൾക്ക് പണം ലഭിച്ചു.");
        return 1;
    }
    if (dialogid == 1006)
    {
        new amount = strval(inputtext);
        if (amount < 1 || amount > g_Money[playerid]) return SendClientMessage(playerid, COLOR_RED, "തുക തെറ്റാണ്."), 1;
        g_Money[playerid] -= amount;
        g_Bank[playerid] += amount;
        ResetPlayerMoney(playerid); GivePlayerMoney(playerid, g_Money[playerid]);
        SaveAccount(playerid);
        new bankQuery[256];
        mysql_format(g_SQL, bankQuery, sizeof bankQuery,
            "INSERT INTO `bank_transactions` (`account_id`,`transaction_type`,`amount`,`note`) VALUES (%d,'DEPOSIT',%d,'ATM deposit')",
            g_AccountID[playerid], amount);
        mysql_tquery(g_SQL, bankQuery);
        SendClientMessage(playerid, COLOR_GREEN, "ബാങ്കിൽ പണം നിക്ഷേപിച്ചു.");
        return 1;
    }
    if (dialogid == 1007)
    {
        new amount = strval(inputtext);
        if (amount < 1 || amount > g_Bank[playerid]) return SendClientMessage(playerid, COLOR_RED, "ബാങ്ക് ബാലൻസ് മതിയാകില്ല."), 1;
        g_Bank[playerid] -= amount;
        g_Money[playerid] += amount;
        ResetPlayerMoney(playerid); GivePlayerMoney(playerid, g_Money[playerid]);
        SaveAccount(playerid);
        new bankQuery[256];
        mysql_format(g_SQL, bankQuery, sizeof bankQuery,
            "INSERT INTO `bank_transactions` (`account_id`,`transaction_type`,`amount`,`note`) VALUES (%d,'WITHDRAW',%d,'ATM withdrawal')",
            g_AccountID[playerid], amount);
        mysql_tquery(g_SQL, bankQuery);
        SendClientMessage(playerid, COLOR_GREEN, "ബാങ്കിൽ നിന്ന് പണം പിൻവലിച്ചു.");
        return 1;
    }
    if (dialogid == 1008 && g_Admin[playerid] >= 4)
    {
        new target, amount;
        if (sscanf(inputtext, "p<,>ii", target, amount)) return SendClientMessage(playerid, COLOR_RED, "Format: PlayerID,Amount"), 1;
        if (!IsPlayerConnected(target) || amount < 0 || amount > 100000000) return 1;
        g_Money[target] = amount;
        ResetPlayerMoney(target); GivePlayerMoney(target, amount);
        SaveAccount(target);
        SendClientMessage(playerid, COLOR_GREEN, "Player money updated.");
        SendClientMessage(target, COLOR_YELLOW, "An administrator updated your wallet balance.");
        new logQuery[256];
        mysql_format(g_SQL, logQuery, sizeof logQuery,
            "INSERT INTO `admin_logs` (`admin_name`,`target_name`,`action`,`details`) VALUES ('%e','%e','SETMONEY','amount=%d')",
            g_PlayerName[playerid], g_PlayerName[target], amount);
        mysql_tquery(g_SQL, logQuery);
        return 1;
    }
    return 0;
}

forward OnLoginPasswordCheck(playerid, password[]);
public OnLoginPasswordCheck(playerid, password[])
{
    if (!IsPlayerConnected(playerid)) return 1;
    if (cache_num_rows() == 0) return Kick(playerid), 1;

    new salt[17], storedHash[65], enteredHash[65];
    cache_get_value_name(0, "salt", salt, sizeof salt);
    cache_get_value_name(0, "password_hash", storedHash, sizeof storedHash);
    SHA256_PassHash(password, salt, enteredHash, sizeof enteredHash);

    if (!strcmp(storedHash, enteredHash, false))
    {
        OnAccountLoaded(playerid);
    }
    else
    {
        g_LoginAttempts[playerid]++;
        if (g_LoginAttempts[playerid] >= 3)
        {
            SendClientMessage(playerid, COLOR_RED, "മൂന്ന് തവണ തെറ്റായ പാസ്‌വേഡ്. വീണ്ടും കണക്റ്റ് ചെയ്യുക.");
            Kick(playerid);
        }
        else
        {
            ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD,
                "Login", "തെറ്റായ പാസ്‌വേഡ്. വീണ്ടും നൽകുക:", "Login", "Quit");
        }
    }
    return 1;
}

stock SaveAccount(playerid)
{
    if (!g_Logged[playerid] || g_AccountID[playerid] == 0) return 0;
    new query[256];
    mysql_format(g_SQL, query, sizeof query,
        "UPDATE `accounts` SET `money`=%d,`bank`=%d,`admin`=%d,`faction`=%d,`faction_rank`=%d,`job`=%d,`level`=%d WHERE `id`=%d",
        g_Money[playerid], g_Bank[playerid], g_Admin[playerid], g_Faction[playerid],
        g_FactionRank[playerid], g_Job[playerid], g_Level[playerid], g_AccountID[playerid]);
    mysql_tquery(g_SQL, query);
    return 1;
}

stock IsLoggedIn(playerid)
{
    if (!g_Logged[playerid])
    {
        SendClientMessage(playerid, COLOR_RED, "ഈ command ഉപയോഗിക്കാൻ ആദ്യം login ചെയ്യുക.");
        return 0;
    }
    return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
    if (!IsLoggedIn(playerid)) return 1;

    if (!strcmp(cmdtext, "/help", true))
    {
        SendClientMessage(playerid, COLOR_YELLOW, "MNRP: /stats /job /work /faction /pay /bank /deposit /withdraw /help");
        SendClientMessage(playerid, COLOR_WHITE, "Admin: /makeadmin (RCON only), /setfaction (admin)");
        return 1;
    }
    if (!strcmp(cmdtext, "/stats", true))
    {
        new msg[160];
        format(msg, sizeof msg, "Level: %d | Money: $%d | Job: %d | Faction: %d | Admin: %d",
            g_Level[playerid], g_Money[playerid], g_Job[playerid], g_Faction[playerid], g_Admin[playerid]);
        SendClientMessage(playerid, COLOR_GREEN, msg);
        return 1;
    }
    if (!strcmp(cmdtext, "/job", true))
    {
        ShowPlayerDialog(playerid, 1002, DIALOG_STYLE_LIST, "ജോലി തിരഞ്ഞെടുക്കുക",
            "1. Fisherman\n2. Delivery Driver\n3. Farmer", "Select", "Close");
        return 1;
    }
    if (!strcmp(cmdtext, "/work", true))
    {
        if (g_Job[playerid] == 0)
        {
            SendClientMessage(playerid, COLOR_RED, "ആദ്യം /job ഉപയോഗിച്ച് ഒരു ജോലി തിരഞ്ഞെടുക്കുക.");
            return 1;
        }
        new now = gettime();
        if (now - g_LastWork[playerid] < 300)
        {
            new waitMsg[96];
            format(waitMsg, sizeof waitMsg, "അടുത്ത ജോലിക്ക് %d seconds കാത്തിരിക്കുക.", 300 - (now - g_LastWork[playerid]));
            SendClientMessage(playerid, COLOR_YELLOW, waitMsg);
            return 1;
        }
        new earnings;
        switch (g_Job[playerid])
        {
            case 1: earnings = 350 + random(151); // Fisherman
            case 2: earnings = 400 + random(201); // Delivery
            case 3: earnings = 300 + random(151); // Farmer
            default: earnings = 250;
        }
        g_LastWork[playerid] = now;
        g_Money[playerid] += earnings;
        GivePlayerMoney(playerid, earnings);
        new earnMsg[96];
        format(earnMsg, sizeof earnMsg, "ജോലി പൂർത്തിയായി! നിങ്ങൾക്ക് $%d ലഭിച്ചു.", earnings);
        SendClientMessage(playerid, COLOR_GREEN, earnMsg);
        SaveAccount(playerid);
        return 1;
    }
    if (!strcmp(cmdtext, "/bank", true))
    {
        new bankMsg[128];
        format(bankMsg, sizeof bankMsg, "Wallet: $%d | Bank: $%d", g_Money[playerid], g_Bank[playerid]);
        SendClientMessage(playerid, COLOR_YELLOW, bankMsg);
        return 1;
    }
    if (!strcmp(cmdtext, "/deposit", true))
    {
        ShowPlayerDialog(playerid, 1006, DIALOG_STYLE_INPUT, "Bank Deposit", "നിക്ഷേപിക്കേണ്ട തുക നൽകുക:", "Deposit", "Cancel");
        return 1;
    }
    if (!strcmp(cmdtext, "/withdraw", true))
    {
        ShowPlayerDialog(playerid, 1007, DIALOG_STYLE_INPUT, "Bank Withdraw", "പിൻവലിക്കേണ്ട തുക നൽകുക:", "Withdraw", "Cancel");
        return 1;
    }
    if (!strcmp(cmdtext, "/faction", true))
    {
        new msg[96];
        format(msg, sizeof msg, "Faction ID: %d | Rank: %d (0 = No faction)", g_Faction[playerid], g_FactionRank[playerid]);
        SendClientMessage(playerid, COLOR_YELLOW, msg);
        return 1;
    }
    if (!strcmp(cmdtext, "/makeadmin", true))
    {
        if (!IsPlayerAdmin(playerid))
        {
            SendClientMessage(playerid, COLOR_RED, "ഈ command RCON admin-ന് മാത്രം.");
            return 1;
        }
        ShowPlayerDialog(playerid, 1003, DIALOG_STYLE_INPUT, "Make Admin",
            "Player ID,Level നൽകുക. ഉദാ: 0,5", "Set", "Cancel");
        return 1;
    }
    if (!strcmp(cmdtext, "/setfaction", true))
    {
        if (g_Admin[playerid] < 3) return SendClientMessage(playerid, COLOR_RED, "Admin level 3 required."), 1;
        ShowPlayerDialog(playerid, 1004, DIALOG_STYLE_INPUT, "Set Faction",
            "PlayerID,FactionID നൽകുക. IDs: 1 Police, 2 Medical, 3 Government, 4 News, 5 Traffic Police, 6 Mechanics", "Set", "Cancel");
        return 1;
    }
    if (!strcmp(cmdtext, "/setmoney", true))
    {
        if (g_Admin[playerid] < 4) return SendClientMessage(playerid, COLOR_RED, "Admin level 4 required."), 1;
        ShowPlayerDialog(playerid, 1008, DIALOG_STYLE_INPUT, "Set Player Money", "PlayerID,Amount നൽകുക:", "Set", "Cancel");
        return 1;
    }
    if (!strcmp(cmdtext, "/pay", true))
    {
        ShowPlayerDialog(playerid, 1005, DIALOG_STYLE_INPUT, "Pay Player",
            "PlayerID,Amount നൽകുക:", "Pay", "Cancel");
        return 1;
    }
    return 0;
}

