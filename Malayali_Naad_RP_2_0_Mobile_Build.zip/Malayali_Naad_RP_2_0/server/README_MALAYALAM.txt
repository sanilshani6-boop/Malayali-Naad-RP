മലയാളി നാട് RP 2.0 — SA-MP 0.3.7

ഉൾപ്പെടുത്തിയിരിക്കുന്നത്:
- MySQL അക്കൗണ്ട് രജിസ്ട്രേഷൻ / ലോഗിൻ
- പണം + ബാങ്ക് ബാലൻസ് save ചെയ്യൽ
- ബാങ്ക്: /bank, /deposit, /withdraw
- ജോലികൾ: /job, /work (5 മിനിറ്റ് cooldown)
- factions: Police, Medical, Government, News, Traffic Police, Mechanics
- admin: /makeadmin, /setfaction, /setmoney
- admin action log table
- Kerala-themed RP location labels (existing GTA SA map-ൽ)

ഇൻസ്റ്റലേഷൻ:
1. MySQL/MariaDB-ൽ scriptfiles/malayali_naad_rp.sql import ചെയ്യുക.
2. gamemodes/MNRP.pwn-ൽ MYSQL_HOST, MYSQL_USER, MYSQL_PASS, MYSQL_DATABASE ശരിയാക്കുക.
3. matching BlueG MySQL plugin + a_mysql.inc ഇൻസ്റ്റാൾ ചെയ്യുക.
4. matching sscanf plugin + sscanf2.inc ഇൻസ്റ്റാൾ ചെയ്യുക.
5. Pawn compiler ഉപയോഗിച്ച് MNRP.pwn compile ചെയ്യുക.
6. server.cfg-ൽ RCON password മാറ്റി server start ചെയ്യുക.

ശ്രദ്ധിക്കുക:
ഇത് വികസിപ്പിക്കാവുന്ന starter source ആണ്; production-ready audited server അല്ല.
Kerala map ഇവിടെ നിലവിലെ GTA San Andreas map-ൽ RP landmark labels ഉപയോഗിച്ചുള്ള theme ആണ്,
പൂർണ്ണ custom Kerala map അല്ല. യഥാർത്ഥ custom map-ന് map objects/streamer assets വേണം.
Public launch-ന് മുമ്പ് anti-cheat, server-side rate limiting, admin audit coverage,
secure password hashing, backup, job mission validation, and load testing ചേർക്കുക.
