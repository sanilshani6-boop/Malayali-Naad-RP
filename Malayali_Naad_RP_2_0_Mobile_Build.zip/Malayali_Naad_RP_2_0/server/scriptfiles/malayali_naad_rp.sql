CREATE DATABASE IF NOT EXISTS `malayali_naad_rp`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `malayali_naad_rp`;

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(24) NOT NULL,
  `password_hash` CHAR(64) NOT NULL,
  `salt` VARCHAR(16) NOT NULL,
  `money` BIGINT NOT NULL DEFAULT 5000,
  `bank` BIGINT NOT NULL DEFAULT 0,
  `admin` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `faction` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `faction_rank` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `job` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `level` INT UNSIGNED NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `factions` (
  `id` TINYINT UNSIGNED NOT NULL,
  `name` VARCHAR(64) NOT NULL,
  `short_name` VARCHAR(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO `factions` (`id`,`name`,`short_name`) VALUES
(1,'Kerala Police Department','KPD'),
(2,'Kerala Medical Services','KMS'),
(3,'Government of Malayali Naad','GOV'),
(4,'Malayali Naad News','MNN'),
(5,'Kerala Traffic Police','KTP'),
(6,'Mechanic Association','MECH');

CREATE TABLE IF NOT EXISTS `faction_ranks` (
  `faction_id` TINYINT UNSIGNED NOT NULL,
  `rank_id` TINYINT UNSIGNED NOT NULL,
  `rank_name` VARCHAR(48) NOT NULL,
  PRIMARY KEY (`faction_id`,`rank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO `faction_ranks` VALUES
(1,1,'Police Trainee'),(1,2,'Police Constable'),(1,3,'Sub Inspector'),(1,4,'Circle Inspector'),(1,5,'Superintendent'),
(2,1,'Intern'),(2,2,'Paramedic'),(2,3,'Doctor'),(2,4,'Chief Medical Officer'),
(3,1,'Clerk'),(3,2,'Officer'),(3,3,'Minister'),(3,4,'Chief Minister'),
(4,1,'Intern Reporter'),(4,2,'Reporter'),(4,3,'Editor'),(4,4,'News Director'),
(5,1,'Traffic Warden'),(5,2,'Traffic Officer'),(5,3,'Inspector'),
(6,1,'Apprentice Mechanic'),(6,2,'Mechanic'),(6,3,'Workshop Manager');

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` TINYINT UNSIGNED NOT NULL,
  `name` VARCHAR(64) NOT NULL,
  `base_pay` INT UNSIGNED NOT NULL DEFAULT 250,
  `cooldown_seconds` INT UNSIGNED NOT NULL DEFAULT 300,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO `jobs` VALUES
(1,'Fisherman',350,300),(2,'Delivery Driver',400,300),(3,'Farmer',300,300);

CREATE TABLE IF NOT EXISTS `businesses` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `owner_account_id` INT UNSIGNED NULL,
  `name` VARCHAR(80) NOT NULL,
  `business_type` VARCHAR(32) NOT NULL,
  `price` BIGINT UNSIGNED NOT NULL DEFAULT 25000,
  `balance` BIGINT NOT NULL DEFAULT 0,
  `x` FLOAT NOT NULL DEFAULT 0, `y` FLOAT NOT NULL DEFAULT 0, `z` FLOAT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`), KEY `idx_business_owner` (`owner_account_id`),
  CONSTRAINT `fk_business_owner` FOREIGN KEY (`owner_account_id`) REFERENCES `accounts`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `properties` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `owner_account_id` INT UNSIGNED NULL,
  `address` VARCHAR(100) NOT NULL,
  `price` BIGINT UNSIGNED NOT NULL DEFAULT 50000,
  `interior` SMALLINT NOT NULL DEFAULT 0,
  `x` FLOAT NOT NULL DEFAULT 0, `y` FLOAT NOT NULL DEFAULT 0, `z` FLOAT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`), KEY `idx_property_owner` (`owner_account_id`),
  CONSTRAINT `fk_property_owner` FOREIGN KEY (`owner_account_id`) REFERENCES `accounts`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `owner_account_id` INT UNSIGNED NULL,
  `model` SMALLINT UNSIGNED NOT NULL,
  `color1` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `color2` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `x` FLOAT NOT NULL DEFAULT 0, `y` FLOAT NOT NULL DEFAULT 0, `z` FLOAT NOT NULL DEFAULT 0,
  `rotation` FLOAT NOT NULL DEFAULT 0,
  `locked` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`), KEY `idx_vehicle_owner` (`owner_account_id`),
  CONSTRAINT `fk_vehicle_owner` FOREIGN KEY (`owner_account_id`) REFERENCES `accounts`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `bank_transactions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `account_id` INT UNSIGNED NOT NULL,
  `transaction_type` VARCHAR(24) NOT NULL,
  `amount` BIGINT NOT NULL,
  `note` VARCHAR(160) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_bank_account` (`account_id`),
  CONSTRAINT `fk_bank_account` FOREIGN KEY (`account_id`) REFERENCES `accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `admin_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `admin_name` VARCHAR(24) NOT NULL,
  `target_name` VARCHAR(24) NOT NULL,
  `action` VARCHAR(32) NOT NULL,
  `details` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_admin_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
