# Malayali Naad RP 2.0 — Release notes

## Android launcher
- Native Kotlin Android app source.
- Dark green / black Kerala-inspired theme.
- Server host and port entry.
- Copy address and launch a compatible client through `samp://`.
- Community overview, rules and connection help.

## SA-MP server
- Expanded Pawn/MySQL starter.
- Persistent wallet, bank, faction, faction rank, job, admin and level.
- Three cooldown-based starter jobs.
- Bank deposit / withdrawal and transaction records.
- Player-to-player payments.
- Six faction definitions and rank data.
- Admin set-faction and set-money actions with logging.
- Kerala-themed landmark labels on the stock San Andreas map.

## Not production-ready yet
This is a starter project, not an audited live service. It needs a custom Kerala map/streamer objects, job mission validation, full faction workflows, vehicle/property/business gameplay, robust admin permission/audit coverage, anti-cheat, backups, load testing, and security review before public launch.
