# Build the APK without Android Studio (using a phone)

You can trigger a free cloud build from a phone browser using GitHub Actions.

1. Create/sign in to a GitHub account at https://github.com.
2. Create a new repository. Public repositories are the easiest way to use GitHub-hosted Actions without consuming private-repository minutes; check GitHub's current usage limits.
3. Upload the contents of this ZIP into the repository, keeping folders intact (especially `.github/workflows/android-apk.yml`).
4. Open the repository's **Actions** tab.
5. Select **Build Malayali Naad RP Android APK**.
6. Tap **Run workflow** and wait for the build to finish.
7. Open the completed workflow run, scroll to **Artifacts**, and download `Malayali-Naad-RP-Launcher-APK`.
8. Extract the downloaded artifact on your phone. Install `app-debug.apk` after allowing installs from that download source.

This uses GitHub's cloud computer; Android Studio is not needed on your phone. GitHub account and current Actions usage limits apply. Do not put passwords, private keys or database credentials in the repository.

The APK is a launcher companion only. It does not contain GTA San Andreas or the SA-MP game client. The server IP/port must be entered in the launcher, and opening `samp://` works only if a compatible client on the phone supports that URI scheme.
